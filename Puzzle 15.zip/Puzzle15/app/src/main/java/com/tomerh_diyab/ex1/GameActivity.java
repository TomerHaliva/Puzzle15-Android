package com.tomerh_diyab.ex1;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;

public class GameActivity extends AppCompatActivity implements View.OnClickListener {

    public static Context context;
    private Chronometer clock;
    private long clockPauseOffset;
    private boolean running;
    protected TextView[] tiles = new TextView[16];
    protected int[] ids = new int[]{R.id.tile1, R.id.tile2, R.id.tile3, R.id.tile4, R.id.tile5, R.id.tile6,
            R.id.tile7, R.id.tile8, R.id.tile9, R.id.tile10, R.id.tile11, R.id.tile12,
            R.id.tile13, R.id.tile14, R.id.tile15, R.id.blankTile};
    boolean musicSwitchState;
    MediaPlayer mp;
    GameBoard board;
    TextView moves ;
    public boolean firstTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        context = this;

        firstTime = true;
        board = new GameBoard();
        for (int i = 0; i < tiles.length; i++) {
            tiles[i] = findViewById(ids[i]);
            tiles[i].setOnClickListener(this);
        }
        clock = findViewById(R.id.clock);
        moves = findViewById(R.id.moves);
        Button newGame = findViewById(R.id.newGame);
        musicSwitchState = getIntent().getBooleanExtra("musicSwitchState", false);
        mp = MediaPlayer.create(this, R.raw.music);


        newGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                board.newGame(tiles, moves, clock);
                startClock(clock);
                if (musicSwitchState)
                    mp.start();
            }
        });
    }

    public void startClock(View v){
        if(!running){
            clock.setBase(SystemClock.elapsedRealtime() - clockPauseOffset);
            clock.start();
            running = true;
        }
    }

    public void pauseClock(View v){
        if(running){
            clock.stop();
            clockPauseOffset = SystemClock.elapsedRealtime() - clock.getBase();
            running = false;
        }
    }

    @Override
    protected void onPause() {

        super.onPause();
        //super.onStop();
        if (musicSwitchState)
            mp.pause();
        pauseClock(clock);

        }

    @Override
    protected void onResume() {
        super.onResume();
        if(firstTime)
            firstTime = false;
        else if(!firstTime){
            startClock(clock);
            if(musicSwitchState)
                mp.start();
        }
    }

    @Override
    public void onClick(View v) {
    int clickedTileID = v.getId();
    board.makeMove(tiles, clickedTileID, moves, clock, context);


    }
}