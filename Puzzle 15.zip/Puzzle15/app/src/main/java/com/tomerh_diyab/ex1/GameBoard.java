package com.tomerh_diyab.ex1;
import android.content.Context;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;

public class GameBoard extends GameActivity{

    boolean GameOver;
    boolean running;
    int size = 4;
    int nbTiles = size * size -1;
    int[] Tiles = new int[] {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,0};
    int blankPos = Tiles.length-1;
    int counter = 0;


    protected void newGame(TextView[] tiles, TextView moves, Chronometer clock){
        do {
            reset(tiles);
            shuffle(tiles);
            initBoardView(tiles);

        } while (!isSolvable());

        moves.setText("Moves: 0000");
        clock.setBase(SystemClock.elapsedRealtime());
        clock.start();
        running = true;

        for(int i=0; i<tiles.length; i++)
            tiles[i].setClickable(true);
        GameOver = false;
    }

    protected void shuffle(TextView[] tiles) {
        Random r = new Random();
        int n = nbTiles + 1;
        while (n > 0){
             int rand = r.nextInt(n--);
             int temp = Tiles[rand];
             Tiles[rand] = Tiles[n];
             Tiles[n] = temp;
             tiles[n].setText(String.valueOf(Tiles[n]));
        }
    }

    protected void reset(TextView[] tiles){
        for(int i=0; i<Tiles.length; i++){
            Tiles[i] = (i+1)%Tiles.length;
            tiles[i].setText(String.valueOf(Tiles[i]));
        }
        blankPos = Tiles.length -1;
    }

    protected boolean isSolvable(){
        int countInversions = 0;

        for(int i=0; i<nbTiles; i++){
            for (int j=0; j<i; j++){
                if(Tiles[j] > Tiles[i])
                    countInversions++;
            }
        }
        return countInversions % 2 == 0;
    }

    protected boolean isSolved(){
        if(Tiles[Tiles.length -1] != 0)
            return false;
        for (int i=nbTiles-1; i>=0; i--){
            if(Tiles[i] != i+1)
                return false;
        }
        return true;
    }

    protected void initBoardView(TextView[] tiles) {

        for (int i = 0; i < Tiles.length; i++) {
            if(tiles[i].getText().toString().equals("0") == false){
                tiles[i].setBackgroundResource(R.drawable.full_border);
                tiles[i].setVisibility(View.VISIBLE);
            }
            else{
                tiles[i].setBackgroundResource(R.drawable.blank_background);
                tiles[i].setVisibility(View.INVISIBLE);
            }
        }
    }

    protected void makeMove(TextView[] tiles, int clickedTileID, TextView moves, Chronometer clock, Context context){
        int blankIndex = getBlankPos(tiles), clickedTileIndex = -1;

        for(int i=0; i<tiles.length; i++){
            if(tiles[i].getId() == clickedTileID){
                clickedTileIndex = i;
                break;
            }
        }
        if(checkLegalClick(tiles,clickedTileIndex,blankIndex)){
            swap(tiles, clickedTileIndex, blankIndex);
            counter++;
            updateMoves(moves, counter);

            GameOver = isSolved();
            if(GameOver){

                Toast endMessage = Toast.makeText(context,"Game Over - Puzzle Solved!",Toast.LENGTH_LONG);
                endMessage.setGravity(Gravity.CENTER,0, 0);
                endMessage.show();

                for(int i=0; i<tiles.length; i++)
                    tiles[i].setClickable(false);
                clock.stop();
            }
        }
    }

    private void updateMoves(TextView moves, int counter){
        if(counter < 10)
            moves.setText("Moves: 000"+counter);
        else if(counter > 9 && counter < 100)
            moves.setText("Moves: 00"+counter);
        else if(counter > 99 && counter < 1000)
            moves.setText("Moves: 0"+counter);
        else
            moves.setText(counter);
    }

    private boolean checkLegalClick(TextView[] tiles, int clickedTileIndex, int blankIndex){
        if(clickedTileIndex == blankIndex+1 || clickedTileIndex == blankIndex-1 || clickedTileIndex == blankIndex+4 || clickedTileIndex == blankIndex-4)
            return true;
        else
            return false;
    }

    private int getBlankPos(TextView[] tiles){
        for (int i=0; i<tiles.length; i++){
            if(tiles[i].getText().toString().equals("0"))
                return i;
        }
        return -1;
    }

    private void swap(TextView[] tiles, int clickedTileIndex, int blankTileIndex){

        int temp = Tiles[clickedTileIndex];
        Tiles[clickedTileIndex] = Tiles[blankTileIndex];
        tiles[clickedTileIndex].setText(String.valueOf(Tiles[blankTileIndex]));
        Tiles[blankTileIndex] = temp;
        tiles[blankTileIndex].setText(String.valueOf(temp));
        initBoardView(tiles);
    }
}
