package com.tomerh_diyab.ex1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {
    private Switch musicSwitch;
    private Button startButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent gameActivity = new Intent(this, GameActivity.class);
        musicSwitch = findViewById(R.id.musicSwitch);
        startButton = findViewById(R.id.startButton);
        MediaPlayer mp = MediaPlayer.create(this,R.raw.music);

        musicSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameActivity.putExtra("musicSwitchState",musicSwitch.isChecked());
            }
        });

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(gameActivity);
            }
        });
    }



    void ExitDialog(){
        AlertDialog.Builder myDialog = new AlertDialog.Builder(this);
        myDialog.setIcon(R.drawable.ic_exit);
        myDialog.setTitle("Exit App");
        myDialog.setMessage("Do you really want to exit Puzzle 15?");
        myDialog.setCancelable(false);
        myDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Log.d("debug", "Yes");
                finish();
            }
        });
        myDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Log.d("debug","No");
            }
        });
        myDialog.show();
    }

    void AboutDialog(){
        AlertDialog.Builder myDialog = new AlertDialog.Builder(this);
        myDialog.setIcon(R.drawable.ic_info);
        myDialog.setTitle("About App");
        myDialog.setMessage("Puzzle 15 ("+getPackageName() +")" +'\n' + "By Tomer Haliva, 26/3/21");
        myDialog.setNegativeButton("Back", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Log.d("debug","Back");
            }
        });

        myDialog.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuItem item1 = menu.add("About");
        MenuItem item2 = menu.add("Exit");

        item1.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                AboutDialog();
                return true;
            }
        });


        item2.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                ExitDialog();
                return true;
            }
        });

        return true;
    }
}

